export const Configuration = {
    LS_NAME: "cart",
    ID_CATALOG: "#catalog",
    ID_CART: "#cart",
    ID_EMPTY: "#empty",
    ID_TOTAL: "#total",
}